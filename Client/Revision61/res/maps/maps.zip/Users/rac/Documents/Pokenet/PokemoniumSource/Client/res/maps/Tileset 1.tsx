<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PGTileset 1" firstgid="0" tilewidth="16" tileheight="16">
 <image source="PGTileseti.png"/>
 <tile id="32">
  <properties>
   <property name="Grass" value="true"/>
  </properties>
 </tile>
 <tile id="837">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="838">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="839">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="869">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="870">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="871">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="901">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="902">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="903">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="934">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="935">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="966">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="967">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
</tileset>
