<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PGTileset 4" firstgid="0" tilewidth="16" tileheight="16">
 <image source="PGTilesetiv.png"/>
 <tile id="924">
  <properties>
   <property name="Animation" value="flower"/>
  </properties>
 </tile>
</tileset>
