<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PGTileset 5" firstgid="0" tilewidth="16" tileheight="16">
 <image source="PGTilesetv.png"/>
</tileset>
