<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PGTileset 7" firstgid="0" tilewidth="16" tileheight="16">
 <image source="PGTilesetvii.png"/>
</tileset>
