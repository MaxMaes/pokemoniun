<?xml version="1.0" encoding="UTF-8"?>
<tileset name="PGTileset 8" firstgid="0" tilewidth="16" tileheight="16">
 <image source="PGTilesetviii.png"/>
 <tile id="789">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="790">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="791">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="821">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="822">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="823">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="853">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="854">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="855">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
</tileset>
