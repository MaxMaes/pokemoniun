<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Kanto Routes 1" firstgid="0" tilewidth="16" tileheight="16">
 <image source="PGTilesetzkantoroutes1.png"/>
</tileset>
