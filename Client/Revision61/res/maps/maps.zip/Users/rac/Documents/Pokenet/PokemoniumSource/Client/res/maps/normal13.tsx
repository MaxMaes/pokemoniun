<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Normal 13" firstgid="0" tilewidth="16" tileheight="16">
 <image source="normal13.png" trans="ffffff"/>
 <tile id="333">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="334">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
</tileset>
