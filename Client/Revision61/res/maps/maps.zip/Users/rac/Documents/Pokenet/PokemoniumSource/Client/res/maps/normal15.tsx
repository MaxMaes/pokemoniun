<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Unbenannt" firstgid="3073" tilewidth="16" tileheight="16">
 <image source="normal15.png" trans="000000"/>
</tileset>
