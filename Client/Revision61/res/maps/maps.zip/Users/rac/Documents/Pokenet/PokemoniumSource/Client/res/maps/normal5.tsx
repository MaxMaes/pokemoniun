<?xml version="1.0" encoding="UTF-8"?>
 <tileset name="1" firstgid="1" tilewidth="16" tileheight="16">
  <image source="normal5.png" trans="000000"/>
 </tileset>