<?xml version="1.0" encoding="UTF-8"?>
 <tileset name="1" firstgid="1" tilewidth="16" tileheight="16">
  <image source="normal6.png" trans="000000"/>
 <tile id="25">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="57">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="88">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="89">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="90">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="120">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="121">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 <tile id="122">
  <properties>
   <property name="Reflection" value="true"/>
  </properties>
 </tile>
 </tileset>